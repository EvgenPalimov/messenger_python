from PyQt5.QtWidgets import QDialog, QPushButton, QLineEdit, QApplication, \
    QLabel, QMessageBox
from PyQt5.QtCore import Qt
import hashlib
import binascii

from server_files.database import ServerStorage


class RegisterUser(QDialog):
    """Класс диалог регистрации пользователя на сервере."""

    def __init__(self, database: ServerStorage, server):
        super().__init__()

        self.database = database
        self.server = server

        self.setWindowTitle("Регистрация")
        self.setFixedSize(175, 183)
        self.setModal(True)
        self.setAttribute(Qt.WA_DeleteOnClose)

        self.label_username = QLabel('Введите имя пользователя:', self)
        self.label_username.move(10, 10)
        self.label_username.setFixedSize(150, 15)

        self.client_name = QLineEdit(self)
        self.client_name.setFixedSize(154, 20)
        self.client_name.move(10, 30)

        self.label_password = QLabel('Введите пароль:', self)
        self.label_password.move(10, 55)
        self.label_password.setFixedSize(150, 15)

        self.client_password = QLineEdit(self)
        self.client_password.setFixedSize(154, 20)
        self.client_password.move(10, 75)
        self.client_password.setEchoMode(QLineEdit.Password)

        self.label_conf = QLabel('Введите пароль еще раз:', self)
        self.label_conf.move(10, 100)
        self.label_conf.setFixedSize(150, 15)

        self.client_conf = QLineEdit(self)
        self.client_conf.setFixedSize(154, 20)
        self.client_conf.move(10, 120)
        self.client_conf.setEchoMode(QLineEdit.Password)

        self.btn_ok = QPushButton('Сохранить', self)
        self.btn_ok.move(10, 150)
        self.btn_ok.clicked.connect(self.save_data)

        self.btn_cancel = QPushButton('Выход', self)
        self.btn_cancel.move(90, 150)
        self.btn_cancel.clicked.connect(self.close)

        self.messages = QMessageBox()
        self.show()

    def save_data(self):
        """
        Функция проверки правильности ввода информации
        и сохранения в базу нового пользователя.

        :return: ничего не возвращает.
        """

        if not self.client_name.text():
            self.messages.critical(
                self, 'Ошибка', 'Не указано имя пользователя.'
            )
            return
        elif self.client_password.text() != self.client_conf.text():
            self.messages.critical(
                self, 'Ошибка', 'Введённые пароли не совпадают.'
            )
            return
        elif self.database.check_user(self.client_name.text()):
            self.messages.critical(
                self, 'Ошибка', 'Пользователь уже существует.'
            )
            return
        else:
            password_bytes = self.client_password.text().encode('utf-8')
            salt = self.client_name.text().lower().encode('utf-8')
            password_hash = hashlib.pbkdf2_hmac('sha512', password_bytes, salt,
                                                100000)
            self.database.add_user(self.client_name.text(),
                                   binascii.hexlify(password_hash))
            self.messages.information(self, 'Успех',
                                      'Пользователь успешно зарегистрирорван.')
            self.server.service_update_lists()
            self.close()


if __name__ == '__main__':
    app = QApplication([])
    app.setAttribute(Qt.AA_DisableWindowContextHelpButton)
    dial = RegisterUser(None, None)
    app.exec_()
